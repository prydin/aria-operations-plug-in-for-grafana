# Changelog

## 1.0.0

Initial release.

## 1.1.0-BETA-1

- Added "percentile()" function.
- Added sliding window functions mavg(), mmin(), mmax(), msum(), mvariance(), mstddev() and mmedian()
